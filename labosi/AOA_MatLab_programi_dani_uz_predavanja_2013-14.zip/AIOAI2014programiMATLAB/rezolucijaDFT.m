% Program ob2_3
% Spektralna analiza signala formiranog kao zbroj dvije sinusoide.
% Primena DFT.
% Demonstracija utjecaja duzine DFT-a, izbor rezolucije
clc;clear;close all;
L=32; % duzina signala x
f1=0.22; f2=0.35; % frekvencije sinusoida
N1=16; N2=32; N3=64; N4=128; %duzine DFT
n=0:L-1;
x=0.5*sin(2*pi*n*f1)+sin(2*pi*n*f2); %signal x
x1=sin(2*pi*n*f2)
figure (1)
set(gcf,'Color',[1,1,1]);
stem((0:L-1),x),title('signal x','Fontsize',22);set(gca,'fontsize',22);grid on;
xlabel('n')
[X,w]=freqz(x,1,1024,'whole'); %spektar signala x'
figure (2)
set(gcf,'Color',[1,1,1]);
plot(w,abs(X)),title('Amplitudni spektar signala x','Fontsize',22);grid;set(gca,'fontsize',22)
xlabel('kruzna frekvencija','Fontsize',22)
X1=fft(x,N1); % DFT za N=16
figure (3)
set(gcf,'Color',[1,1,1]);
stem((0:N1-1),abs(X1)),title('DFT za N=16','Fontsize',22)
xlabel('k','Fontsize',22);set(gca,'fontsize',22);grid on;
X2=fft(x,N2); % DFT za N=32
figure (4)
set(gcf,'Color',[1,1,1]);
stem((0:N2-1),abs(X2)),title('DFT za N=32','Fontsize',22)
xlabel('k','Fontsize',22);set(gca,'fontsize',22);grid on;
X3=fft(x,N3); % DFT za N=64
figure (5)
set(gcf,'Color',[1,1,1]);
stem((0:N3-1),abs(X3)),title('DFT za N=64','Fontsize',22)
xlabel('k','Fontsize',22);set(gca,'fontsize',22);grid on;
X4=fft(x,N4); % DFT za N=16
figure (6)
set(gcf,'Color',[1,1,1]);
stem((0:N4-1),abs(X4)),title('DFT za N=128','Fontsize',22)
xlabel('k','Fontsize',22);set(gca,'fontsize',22);grid on;