%%Amplitude modulation ----Single Tone Modulation

clear;clc;close all;
Ac=2;
%Carrier frequency
Fc=5000;
%baseband frequency
Fm=200;
%sampling
Fs=100000;
%%undermodulation
mu=0.6;
t=0:1/Fs:1;
mt=cos(2*pi*Fm*t);
st=Ac*(1+mu*mt).*cos(2*pi*Fc*t);
uVF=Ac*cos(2*pi*Fc*t);
figure(1)
set(gcf,'Color',[1,1,1]);
subplot(2,1,1);
plot(t/1000,mt,'Linewidth',3);
%title('Signali kod AM postupka','Fontsize',10);
xlabel('t[ms]','Fontsize',20);ylabel('u_m(t)','Fontsize',20);set(gca,'fontsize',20);grid on;
subplot(2,1,2);
plot(t,uVF,'Linewidth',3);
%title('Prijenosni signal u vremenskoj domeni','Fontsize',12);
xlabel('t[ms]','Fontsize',20);ylabel('u_V_F(t)','Fontsize',20);set(gca,'fontsize',20);grid on;
figure(3)
set(gcf,'Color',[1,1,1]);
%subplot(2,1,1);
plot(t*1000,st,t*1000,Ac*(mu*mt+ones(1,length(mt))),'r','Linewidth',3);
%title('AM signal u vremenskoj domeni uz m=0.5','Fontsize',12);
xlabel('t[ms]','Fontsize',20);ylabel('u_A_M(t)','Fontsize',20);
set(gca,'fontsize',20);grid on;

st_fft=fft(st);
N=length(st_fft);
df=Fs/N;
a=st_fft(1:N/2)/(N/2);
f=(0:Fs/N:Fs*(N/2-1)/N);
figure(4)
set(gcf,'Color',[1,1,1]);
%subplot(2,1,2);
plot(f(1:N/5),abs(a(1:N/5)),'Linewidth',3);
%title('Amplitudni spektar AM moduliranog signala uz m_a=0.5','Fontsize',12);grid on;
xlabel('f[Hz]','Fontsize',20);ylabel('\midU_A_M(f)\mid','Fontsize',20);set(gca,'fontsize',20);grid on;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%total modulation
figure(5);
set(gcf,'Color',[1,1,1]);
mu=1;
t=0:1/Fs:1;
mt=cos(2*pi*Fm*t);
st=Ac*(1+mu*mt).*cos(2*pi*Fc*t);
subplot(2,1,1);
plot(t,st,t,Ac*(mu*mt+ones(1,length(mt))),'r','Linewidth',3);grid on;
title('AM signal u vremenskoj domeni uz m_a=1','Fontsize',22);
xlabel('t[s]','Fontsize',22);ylabel('u_A_M(t)','Fontsize',22);set(gca,'fontsize',22);grid on;
st_fft=fft(st);
N=length(st_fft);
df=Fs/N;
a=st_fft(1:N/2)/(N/2);
f=(0:Fs/N:Fs*(N/2-1)/N);
subplot(2,1,2);
plot(f(1:N/5),abs(a(1:N/5)),'Linewidth',3);
title('Amplitudni spektar AM moduliranog signala uz m_a=1','Fontsize',22);grid on;
xlabel('f[Hz]','Fontsize',22);ylabel('\midU_A_M(f)\mid','Fontsize',22);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%overmodulation
figure(6);
set(gcf,'Color',[1,1,1]);
mu=2;
t=0:1/Fs:1;
mt=cos(2*pi*Fm*t);
st=Ac*(1+mu*mt).*cos(2*pi*Fc*t);
subplot(2,1,1);
plot(t,st,t,abs(Ac*(mu*mt+ones(1,length(mt)))),'r','Linewidth',3);grid on;
title('AM signal u vremenskoj domeni uz m_a=2','Fontsize',22);
xlabel('t[s]','Fontsize',22);ylabel('u_A_M(t)','Fontsize',22);set(gca,'fontsize',22);
st_fft=fft(st);
N=length(st_fft);
df=Fs/N;
a=st_fft(1:N/2)/(N/2);
f=(0:Fs/N:Fs*(N/2-1)/N);
subplot(2,1,2);
plot(f(1:N/5),abs(a(1:N/5)),'Linewidth',3);
title('Amplitudni spektar AM moduliranog signala uz m_a=2','Fontsize',22);grid on;
xlabel('f[Hz]','Fontsize',22);ylabel('\midU_A_M(f)\mid','Fontsize',22);set(gca,'fontsize',22);
