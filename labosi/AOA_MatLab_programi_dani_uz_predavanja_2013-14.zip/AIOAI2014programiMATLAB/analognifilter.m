%primjer kada imamo prijenosnu funkciju kontinuiranu RC niski propust
clc;clear;close all;
%prvi analogni filtar
num=[1]
den=[0.001 1]
figure(1);
set(gcf,'Color',[1,1,1])
freqs(num,den)
%drugi analogni filtar
den1=[1 0.4 3];
num1=[0.2 0.3 1 ];
%moguce odrediti raspon frekvencija u kojem ce crtati
w=logspace(-1,1);
h=freqs(num1,den1,w);
mag=abs(h);
phase=angle(h);
mag1=20*log10(mag);
phase1=phase*180/pi;
figure(2);
set(gcf,'Color',[1,1,1]);
subplot(2,1,1), semilogx(w,mag1);xlabel('w[rad/s]');ylabel('A[dB]');% u decibelima amplitudna karakteristika
subplot(2,1,2), semilogx(w,phase1);xlabel('w[rad/s]');ylabel('Faza [stupnjevi]');




