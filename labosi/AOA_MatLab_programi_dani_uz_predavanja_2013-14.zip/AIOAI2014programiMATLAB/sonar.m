% simulacija sonarnog sustava sa kriznom korelacijom
n=0:255;clear;clc;
P=input('Zadaj snagu  Gaussovog suma P='); 
x=zeros(1,256);
N=0:19;N1=1:50;N2=71:256;
s=5*sin(2*pi*N*500/5000);
xpob=s(1:20);xpob(21:256)=x(21:256);
ypri(1:50)=x(1:50)+sqrt(P)*randn(1,50);
ypri(51:70)=0.3*xpob(1:20)+sqrt(P)*randn(size(N));

ypri(71:256)=xpob(71:256)+sqrt(P)*randn(size(N2));
figure(1);
set(gcf,'Color',[1,1,1]);
subplot(211);plot(xpob,'Linewidth',3);xlabel('n','Fontsize',22);ylabel('x(n)','Fontsize',22);set(gca,'fontsize',22);grid on;title('Pobudni signal i prijemni signal','Fontsize',22);
subplot(212);plot(ypri,'Linewidth',3);xlabel('n','Fontsize',22);ylabel('y(n)','Fontsize',22);set(gca,'fontsize',22);grid on;

z=xcorr(ypri,xpob,'coeff');
figure(2);
set(gcf,'Color',[1,1,1]);
plot(z(256:511),'Linewidth',3);xlabel('n','Fontsize',22);ylabel('Corr(x,y)','Fontsize',22);title('Krizna korelacija pobudnog i prijemnog signala','Fontsize',22);
set(gca,'fontsize',22);grid on;

[k,i]=max(z);
fprintf('Maksimum krizne korelacijske funkcije je %2f\n, Mjesto uzorka %d',k,i-256);
Pyx=csd(xpob ,ypri);
figure(3);
pha=angle(Pyx);phase=unwrap(pha);
plot(phase,'Linewidth',3);
