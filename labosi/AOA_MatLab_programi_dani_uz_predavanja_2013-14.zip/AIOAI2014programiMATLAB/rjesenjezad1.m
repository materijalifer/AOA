clear;clc;close all;
fs1=16000;
dt1=1/fs1;
t=0:dt1:3;  % prvo zadajemo vektor vremena t
w0=2*pi*1000;
y1=1*cos(w0*t+pi/180*30);
figure(1); %slika signala 1
set(gcf,'Color',[1,1,1]);
plot(t(1:100),y1(1:100),'Linewidth',3)   
ylabel('u(t)','FontSize',22);
xlabel('t[s]','FontSize',22);
set(gca,'fontsize',22);grid on;
figure(2); %slika signala 1
set(gcf,'Color',[1,1,1]);
stem(t,y1,'o','Linewidth',2)   
ylabel('u(t)','FontSize',22);
xlabel('t[s]','FontSize',22);
set(gca,'fontsize',22);grid on;
% amplitudni i fazni spektar signala
Y1=fft(y1);
n=size(Y1);
N=n(2);
df=fs1/N;
a1=Y1(1:N/2)/(N/2);
f=(0:fs1/N:fs1*(N/2-1)/N);
figure(3);
set(gcf,'Color',[1,1,1]);
subplot(211)
stem(f(1:10000),abs(a1(1:10000)),'Linewidth',3), xlabel('f[Hz]','Fontsize',22);ylabel('\midX(f)\mid','Fontsize',22);title('Amplitudni spektar ulaznog signala','Fontsize',24);
set(gca,'fontsize',22);grid on;
subplot(212)
plot(f(1:10000),(angle(a1(1:10000))),'Linewidth',3), xlabel('f[Hz]','Fontsize',22);ylabel('faza(X(f))[rad]','Fontsize',22);title('Fazni spektar ulaznog signala','Fontsize',24);
set(gca,'fontsize',22);grid on;
%zapisivanje u wav. file;
wavwrite(y1,16000,16,'sig1');
