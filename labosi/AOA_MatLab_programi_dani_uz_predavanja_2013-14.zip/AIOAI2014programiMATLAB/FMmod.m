clear;clc;close all;
%postavke signala
vc=1; %amplituda nosioca
vm=1; %amplituda modulacijskog signala
fm=500; %frekvencija modulacijskog signala
fc=15000; %frekvencija nosioca
m=5; %indeks frekvencijske modulacije
% x-axis:Time(second)
t=0:0.00001:1.09999; %vrijeme za promatranje signala
dt=0.00001;
fs=1/dt;
%frekvencija prijenosnog signala
wc=2*pi*fc;
%frekvencija modulacijskog signala
wm=2*pi*fm;
sc_t=vc*cos(wc*t); 
sm_t=vm*cos(wm*t);
%FM signal
s_fm=vc*cos((wc*t)+m*sin(wm*t));
%ra�unanje amplitudnog spektra kori�tenjem naredbe fft
vf=abs(fft(s_fm,10000));
N=length(vf);
vf=vf/N;

% Plot figure in time domain
figure(1);
set(gcf,'Color',[1,1,1]);
plot(t,s_fm);
hold on;
plot(t,sm_t,'r');
xlabel('t(s)'),ylabel('u_F_M(t)');axis([0 0.01 -1.5 1.5]);
title('FM vremenska domena');
grid on; 

% Plot figure in frequency domain
figure(2);
set(gcf,'Color',[1,1,1]);
N=length(vf)
f=0:fs/N:(N/2-1)*fs/N;%frekvencijski vektor za prikaz
plot(f/1000,(vf(1:N/2)));
title('FM signal u frekvencijskoj domeni');
grid on;xlabel('f[kHz]','Fontsize',22);ylabel('\midU_F_M(f)\mid','Fontsize',22);title('Amplitudni spektar FM moduliranog signala','Fontsize',24);
axis([0 50 0 0.5]);
set(gca,'fontsize',22);grid on;

