% Program ob2_5
% Spektralna analiza signala formiranog kao zbroj dvije sinusoide.
% Primjena DFT.
% Demonstracija primjene Hanovog prozora u vremenskoj i frekvencijskoj
% domeni
clear;clc;close all;
L=64; % duzina signala x
f1=0.22; f2=0.34; % frekvencija sinusoida
N1=64; N2=32; N3=64; N4=128; %duzine DFT
n=0:L-1;
x=0.5*sin(2*pi*n*f1)+sin(2*pi*n*f2); %signal x
figure (1)
stem((0:L-1),x),title('signal x(n)')
xlabel('n')
X=fft(x,N1); % DFT za N=64
figure (2)
stem((0:N1-1),abs(X)),title('DFT za za signal x(n), N=64')
xlabel('k')
% Hannov prozor
for n=0:L   wh(n+1)=0.5*(1-cos((2*pi*n)/L));
   end
v=wh(1:L).*x; % Primjena Hannovog prozora na signal x
V1=fft(v,N1); % DFT za N=64 i Hannov prozor
figure (3)
stem((0:N1-1),abs(V1)),title('DFT za signal v(n), Hanningov prozor, N=64')
xlabel('k')
% % Primjena Hannovog prozora u frekvencijskoj domeni, ciklicka konvolucija
% V2(1)=0.5*(X(1)-0.5*(X(N1)+X(2))); 
% for k=2:N1-1
%    V2(k)=0.5*(X(k)-0.5*(X(k-1)+X(k+1)));
% end
% V2(N1)=0.5*(X(N1)-0.5*(X(N1-1)+X(1)));
% figure (4)
% stem((0:N1-1),abs(V2)),title('V(k) Hannov prozor preko ciklicke konvolucije, N=64')
% xlabel('k')
% greska=abs(V1)-abs(V2); % Numericka greska 
% figure (5)
% stem((0:N1-1),greska),title('Numericka greska')
% xlabel('k')

% Komentari:
% 1. Usporedbom spektra dobijenog sa pravokutnim i Han-ovim prozorom opaza se 
% da je kod Hanningovog prozora glavni luk siri ali je potiskivanje bocnih latica mnogo bolje.
