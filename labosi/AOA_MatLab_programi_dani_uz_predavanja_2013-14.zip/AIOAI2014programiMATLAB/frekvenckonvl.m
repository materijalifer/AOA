%pr.1 konstruirati i nacrtati diskretne signale i njihovu konvoluciju
clc;clear;close all;
N1=30;
n1=0:N1-1;x=0.9.^n1;
N2=40;
n2=0:N2-1;y=0.8.^n2;
figure(1);
set(gcf,'Color',[1,1,1]);
subplot(1,2,1),stem(n1,x),xlabel('n','Fontsize',22),ylabel('y(n)','Fontsize',22); title('signal x(n)','Fontsize',22);
subplot(1,2,2),stem(n2,y),xlabel('n','Fontsize',22),ylabel('y(n)','Fontsize',22);title('signal y(n)','Fontsize',22);
[H1,w]=freqz( 1, [1 -0.9], 80,'whole');
[H2,w]=freqz( 1, [1 -0.8] , 80 ,'whole');

amp1=abs(H1);amp2=abs(H2);
phase1=angle(H1); phase2=angle(H2);

figure(2);
set(gcf,'Color',[1,1,1]);
subplot(211)
semilogy(w,amp1,'Linewidth',3);
xlabel('Kruzna frekvencija po uzorku od 0 do 2*pi','Fontsize',22);ylabel('\midX1\mid','Fontsize',22);grid on;
subplot(212); 
plot(w,phase1,'Linewidth',3);xlabel('Kruzna frekvencija po uzorku od 0 do 2*pi','Fontsize',22);ylabel('faza(X1)','Fontsize',22);grid on;
figure(3);
set(gcf,'Color',[1,1,1]);
subplot(211)
semilogy(w,amp2);xlabel('Kruzna frekvencija po uzorkuod 0 do 2*pi','Fontsize',22);ylabel('\midX2\mid','Fontsize',22);grid on;
subplot(212); plot(w,phase2);xlabel('Kruzna frekvencija po uzorku od 0 do 2*pi','Fontsize',22);ylabel('faza X2','Fontsize',22);grid on;
% ako se zada frekvencija uzorkovanja;
%ako zadamo frekvenciju kojom su dobiveni uzorkovani signali

[G1,f]=freqz( 1,[1 -0.9],100,1000,'whole');
amplg1=abs(G1);
phaseg1=angle(G1);
figure(4);
set(gcf,'Color',[1,1,1]);
subplot(211)
semilogy(f,amplg1,'Linewidth',3);xlabel('f[Hz]','Fontsize',22);ylabel('\midX1\mid','Fontsize',22);grid on;
subplot(212); 
plot(f,phaseg1,'Linewidth',3');xlabel('f[Hz]','Fontsize',22);ylabel('faza X1','Fontsize',22);grid on;


%konvolucija ova dva signala'
N3=N1+N2-1;% duzina niza 
n3=0:N3-1;
h=conv(x,y);
figure(5);
set(gcf,'Color',[1,1,1]);
stem(n3,h,'Linewidth',3);xlabel('n','Fontsize',22),ylabel('h(n)','Fontsize',22); title('Konvolucija x(n)*y(n)','Fontsize',22);grid on;
set(gca,'fontsize',22);grid on;
%pr.2
figure(6);
set(gcf,'Color',[1,1,1]);
x1=ones(1,20);
x2=ones(1,10);
h1=conv(x1,x2);
subplot(131),stem(x1),xlabel('n'),ylabel('x1(n)','Fontsize',22),title('niz x1(n)');grid on;
subplot(132),stem(x2),xlabel('n'),ylabel('x2(n)','Fontsize',22),title('niz x2(n)');grid on;
subplot(133),stem(h1),xlabel('n'),ylabel('h12(n)','Fontsize',22),title('niz h1(n)');grid on;
set(gca,'fontsize',22);grid on;



