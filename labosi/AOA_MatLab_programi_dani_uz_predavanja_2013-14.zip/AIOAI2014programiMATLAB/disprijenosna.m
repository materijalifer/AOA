%funkcija prijenosa i impulsni odziv  sustava
clc;clear;close all;
Q=[0.0647  -0.0106 0.0997 -0.0106 0.0647];
P=[1 -2.280 2.6543 -1.5624 0.4215];
figure(1);
set(gcf,'Color',[1,1,1]);
set(gca,'fontsize',22);grid on;

[Hz,Hp]=zplane(Q,P);

[H,w]=freqz(Q,P,256);
ampl=abs(H);fazna=angle(H);
figure(2);
set(gcf,'Color',[1,1,1]);
subplot(211),plot(w,ampl,'k','Linewidth',3),xlabel('w[s-1]','Fontsize',22);ylabel('abs(H)','Fontsize',22),title('Amplitudna frekvencijska karakteristika','Fontsize',22);
set(gca,'fontsize',22);grid on;
subplot(212),plot(w,fazna,'k','Linewidth',3),xlabel('w[s-1]','Fontsize',22);ylabel('angle(H)','Fontsize',22),title('Fazna frekvencijska karakteristika','Fontsize',22);
set(gca,'fontsize',22);grid on;
%grupno kasnjenje
figure(3);
set(gcf,'Color',[1,1,1]);
[gd,w]=grpdelay(Q,P,256);
subplot(121);plot(w,gd,'k'),xlabel('w[s-1]','Fontsize',22),ylabel('(gd(w))','Fontsize',22),title('Grupno kasnjenje','Fontsize',22);
set(gca,'fontsize',22);grid on;
%impulsni odziv
subplot(122);
set(gcf,'Color',[1,1,1]);
impz(Q,P,50);
xlabel('t[s]','Fontsize',22),ylabel('tau(t)','Fontsize',22)
title('Impulsni odziv','Fontsize',22);set(gca,'fontsize',22);grid on;



