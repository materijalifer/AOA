%impulsni signal
%gauss pulse in MATLAB
clear;clc;close all;
tc = gauspuls('cutoff',6E3,.4,[],-40);
        t  = -4*tc : 1/100000 : 30*tc;
        yi = gauspuls(t,6E3,.4); 
        t=t+4*tc;
        
   figure(1)
  set(gcf,'Color',[1,1,1]);
  plot(t,yi,'Linewidth',2);xlabel('t[s]','Fontsize',22);ylabel('u(t)','Fontsize',22);title('Gaussov moduliran sinusni signal','Fontsize',22);grid on;
 set(gca,'Fontsize',22);grid on;
 
  figure(11)
  set(gcf,'Color',[1,1,1]);
  stem(t,yi,'Linewidth',2);xlabel('t[s]','Fontsize',22);ylabel('u(t)','Fontsize',22);title('Gaussov moduliran sinusni signal','Fontsize',22);grid on;
 set(gca,'Fontsize',22);grid on;
 %spectrum calculation
 fs=100000;
 X=fft(yi);
 N=length(X)
 f=0:fs/N:(N/2-1)/N*fs;
 figure(2)
 set(gcf,'Color',[1,1,1]);
plot(f(1:N/2)/1000,abs(X(1:N/2)),'Linewidth',3);xlabel('f[kHz]','Fontsize',22);ylabel('\mid X(f)\mid','Fontsize',22);grid on;
set(gca,'Fontsize',22);grid on;
 figure(3)
 set(gcf,'Color',[1,1,1]);
 plot(f(1:N/2)/1000,unwrap(angle(X(1:N/2))));xlabel('f[kHz]');ylabel('angle((X(f))[rad]');grid on;
wavwrite(yi,16000,16,'sig2');