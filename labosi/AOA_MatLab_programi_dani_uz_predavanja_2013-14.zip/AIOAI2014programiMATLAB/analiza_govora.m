 
% Izracunavanje spektrograma i crtanje u tri dimenzije
clear;clc;close all;
t=0:0.001:2;                    % 2 secs @ 1kHz sample rate
      x=chirp(t,0,1,150);             % Start @ DC, cross 150Hz at t=1sec 
      F = 0:.1:100;
      [y,f,t,p] = spectrogram(x,256,250,F,1E3,'yaxis'); 
      % NOTE: This is the same as calling SPECTROGRAM with no outputs.
      surf(t,f,10*log10(abs(p)),'EdgeColor','none');   
      axis xy; axis tight; colormap(jet); view(0,90);
      xlabel('Time');
      ylabel('Frequency (Hz)');
 