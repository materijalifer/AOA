function hello
% ovo je funkcija hello 
%autor:Antonio
%datum:17.2.2011
disp('U Matlabu smo: pozdrav');