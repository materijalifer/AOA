%prikazati autokorelaciju funkcije duljine N
clear;clc;close all;
N=1024;
n=0:N-1;
f1=1;
fs=200;
x=2*sin(2*pi*f1*n/fs);
t=[1 :N]*1/fs;
figure(1);
set(gcf,'Color',[1,1,1]);
plot(x,'Linewidth',3);ylabel('x(t)','Fontsize',22);xlabel('m','Fontsize',22);grid;
set(gca,'fontsize',22);grid on;
Rxx=xcorr(x,'coeff');

figure (2)
set(gcf,'Color',[1,1,1]);

plot(Rxx,'Linewidth',3);xlabel('m','Fontsize',22);ylabel('Rxx(m)','Fontsize',22);
set(gca,'fontsize',22);grid on;
grid on;

