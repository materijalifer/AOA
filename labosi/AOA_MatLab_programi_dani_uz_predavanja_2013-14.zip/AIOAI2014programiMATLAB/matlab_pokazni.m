%pokazni primjer u MATLAB-u
clear;
clc;
close all;
t = [0:0.01:10]  % prvo zadajemo vektor vremena t
f=1
x = sin(2*pi*f*t);  % sada definiramo sinusni signal
figure(1); % slika koju ce nactrati je objekt Figure 1
set(gcf,'Color',[1,1,1]) %mijenjanje boje u pozadini 
plot(t,x)  % kojeg na kraju nacrtamo u t-x koordinatnom sustavu
set(gca,'fontsize',22);

figure (2);
set(gcf,'Color',[1,1,1])
plot(t,x,'-','Linewidth',3); xlabel('t[s]','Fontsize',22);ylabel('x(t)','Fontsize',22);title('Probni signal','Fontsize',24);
set(gca,'fontsize',22);

figure(3);
subplot(2,1,1); plot(t,x);
subplot(2,1,2);plot(t);
h=figure(3); % h je objekt koji cini slika 1
get(h)  % dohvacamo svojstva objekta i ako nema ; onda se ispisuju u komandnoj liniji
set(h,'Name','Slicica');

