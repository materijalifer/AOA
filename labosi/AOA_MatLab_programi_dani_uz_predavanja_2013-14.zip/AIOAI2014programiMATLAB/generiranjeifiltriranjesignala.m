clear;clc;close all
%Generirati slozeni periodicki signal
fs=8192;
dt=1/fs;
t=0:dt:7; w0=2*pi*100;
y=0.5*cos(w0*t)+0.8*cos(10*w0*t);
n=size(y);

figure(1); %slika signala 1
set(gcf,'Color',[1,1,1]);
plot(t,y,'Linewidth',3)   
ylabel('u(t)','FontSize',22);
xlabel('t[s]','FontSize',22);
set(gca,'fontsize',22);grid on;
%racunanje spektra signala
Y=fft(y);
N=n(2);
a1=(abs(Y(1:N/2)))/(N/2);
f=(0:fs/N:fs*(N/2-1)/N);
figure(2);
set(gcf,'Color',[1,1,1])
stem(f,a1), xlabel('f[Hz]','Fontsize',20),title('Amplitudni spektar ulaznog signala');
set(gca,'fontsize',18);
%realizirati digitalni  niskopropusni filtar Butterworth
Wn=400/(fs/2); %granicna frekvencija normirana na pola frekvencije uzorkovanja
[b,a]=butter(3,Wn);
%prijenosna funkcija filtra
[H,f]=freqz(b,a,256,8192);
Mag=abs(H);
figure (3)
set(gcf,'Color',[1,1,1])
plot(f,Mag,'Linewidth',3),xlabel('f[Hz]','Fontsize',20);ylabel('abs(A)','Fontsize',20);
set(gca,'fontsize',18);
grid on;
%prikaz impulsnog odziva digitalnog sustava
figure(4);
set(gcf,'Color',[1,1,1])
[H,T] = impz(b,a,[],8192);
stem(T,H,'Linewidth',3);xlabel('t[s]','Fontsize',20);ylabel('h(t)','Fontsize',20);
set(gca,'fontsize',18);
%propustamo signal kroz filtar
h=filter(b,a,y);
H=fft(h);
n=size(h);
N=n(2);
%amplitudni i fazni spektar propustenog signala kroz filtar
a2=(abs(H(1:N/2)))/(N/2);
f=(0:fs/N:fs*(N/2-1)/N);
figure(5);
set(gcf,'Color',[1,1,1])
stem(f,a2), xlabel('f[Hz]','Fontsize',20);title('Amplitudni spektar izlaznog signala');
set(gca,'fontsize',18);
wavwrite(y,8192,16,'sig3');
wavwrite(h,8192,16,'izlazni signal');










